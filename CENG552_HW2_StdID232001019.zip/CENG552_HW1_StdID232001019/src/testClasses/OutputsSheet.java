package testClasses;

import java.io.IOException;

import guiClasses.Mainscreen;

public class OutputsSheet {

	
	public static String[] loadingOutputs() throws IOException{
		
		return LoadingSheet.getSheet(2, Mainscreen.getPath());
	
	}
	
}
