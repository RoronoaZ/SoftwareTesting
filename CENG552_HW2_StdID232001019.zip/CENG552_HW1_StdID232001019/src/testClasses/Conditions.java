package testClasses;

import java.io.IOException;

import guiClasses.Mainscreen;

public class Conditions {

	
	
	public static String[] loadingConditions() throws IOException{
		
		return LoadingSheet.getSheet(3, Mainscreen.getPath());
	
	}
	
	
}
