package testClasses;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

public class CTCNextDate extends JPanel {

	private static final int CHECK_COL = 1;
    private static final Object[][] DATA = {
        {"Class Day 1", Boolean.TRUE}, {"Class Day 2", Boolean.FALSE},
        {"Class Day 3", Boolean.FALSE}, {"Class Day 4", Boolean.FALSE},
        {"Class Day 5", Boolean.FALSE}, {"Class Month 1", Boolean.TRUE},
        {"Class Month 2", Boolean.FALSE}, {"Class Month 3", Boolean.FALSE},
        {"Class Month 4", Boolean.FALSE}, {"Class Year 1", Boolean.FALSE}, {"Class Year 2",Boolean.FALSE}};
    
    private static final String[] COLUMNS = {"Conditions", "Rules"};
    private DataModel dataModel = new DataModel(DATA, COLUMNS);
    private JTable table = new JTable(dataModel);

    public CTCNextDate() {
        super(new BorderLayout());
        this.add(new JScrollPane(table));
        table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        table.setPreferredScrollableViewportSize(
             new Dimension(250, 10 * table.getRowHeight()));
    }

    public JTable getTable(){
    	return this.table;
    	
    }
    
    private class DataModel extends DefaultTableModel {

        public DataModel(Object[][] data, Object[] columnNames) {
            super(data, columnNames);
        }

        @Override
        public void setValueAt(Object value, int row, int col) {		//Setting which classes can be selected together
            super.setValueAt(value, row, col);
            if (col == 1) {
            	if (row == 0){
            		for (int i=0; i<5; i++ )
            			if (row !=0)
            				if ((Boolean) this.getValueAt(i, col) == true)
            					this.setValueAt(false, i, col);
            					
            					
            		if ((Boolean) this.getValueAt(0, col) == true ){
            			if ((Boolean) this.getValueAt(1, col) == true)
            				this.setValueAt(false, 1, col);
            		this.setValueAt(false, 2, col);
            		this.setValueAt(false, 3, col);
            		this.setValueAt(false, 4, col);
            		}
            	}else
            	if (row == 1){
            		for (int i=0; i<5; i++ )
            			if (row !=1)
            				if ((Boolean) this.getValueAt(i, col) == true)
            					this.setValueAt(false, i, col);
            		
            		if ((Boolean) this.getValueAt(1, col) == true ){
            			
            			this.setValueAt(false, 0, col);
            			this.setValueAt(false, 2, col);
            			this.setValueAt(false, 3, col);
            			this.setValueAt(false, 4, col);
            		}
            	}else
            		if (row == 2){
            			for (int i=0; i<5; i++ )
                			if (row !=2)
                				if ((Boolean) this.getValueAt(i, col) == true)
                					this.setValueAt(false, i, col);
                		
                		if ((Boolean) this.getValueAt(2, col) == true ){
                			
                			this.setValueAt(false, 0, col);
                			this.setValueAt(false, 1, col);
                			this.setValueAt(false, 3, col);
                			this.setValueAt(false, 4, col);
                		}
            			
            		}else
                		if (row == 3){
                			for (int i=0; i<5; i++ )
                    			if (row !=3)
                    				if ((Boolean) this.getValueAt(i, col) == true)
                    					this.setValueAt(false, i, col);
                    		
                    		if ((Boolean) this.getValueAt(3, col) == true ){
                    			
                    			this.setValueAt(false, 0, col);
                    			this.setValueAt(false, 1, col);
                    			this.setValueAt(false, 2, col);
                    			this.setValueAt(false, 4, col);
                    		}
                			
                		}else
                    		if (row == 4){
                    			for (int i=0; i<5; i++ )
                        			if (row !=4)
                        				if ((Boolean) this.getValueAt(i, col) == true)
                        					this.setValueAt(false, i, col);
                        		
                        		if ((Boolean) this.getValueAt(4, col) == true ){
                        			
                        			this.setValueAt(false, 0, col);
                        			this.setValueAt(false, 1, col);
                        			this.setValueAt(false, 2, col);
                        			this.setValueAt(false, 3, col);
                        		}
                    			
                    		}
                    	
                        if (row == 5){
                        	for (int i=5; i<9; i++ )
                            	if (row !=5)
                            		if ((Boolean) this.getValueAt(i, col) == true)
                            			this.setValueAt(false, i, col);
                            		
                            	if ((Boolean) this.getValueAt(5, col) == true ){
                            			
                            		this.setValueAt(false, 6, col);
                            		this.setValueAt(false, 7, col);
                            		this.setValueAt(false, 8, col);
                            		
                            	}
                        			
                        }else
                        	if (row == 6){
                            	for (int i=5; i<9; i++ )
                                	if (row !=6)
                                		if ((Boolean) this.getValueAt(i, col) == true)
                                			this.setValueAt(false, i, col);
                                		
                                	if ((Boolean) this.getValueAt(6, col) == true ){
                                			
                                		this.setValueAt(false, 5, col);
                                		this.setValueAt(false, 7, col);
                                		this.setValueAt(false, 8, col);
                                		
                                	}
                            			
                            }else
                            	if (row == 7){
                                	for (int i=5; i<9; i++ )
                                    	if (row !=7)
                                    		if ((Boolean) this.getValueAt(i, col) == true)
                                    			this.setValueAt(false, i, col);
                                    		
                                    	if ((Boolean) this.getValueAt(7, col) == true ){
                                    			
                                    		this.setValueAt(false, 5, col);
                                    		this.setValueAt(false, 6, col);
                                    		this.setValueAt(false, 8, col);
                                    		
                                    	}
                                			
                                }else
                                	if (row == 8){
                                    	for (int i=5; i<9; i++ )
                                        	if (row !=8)
                                        		if ((Boolean) this.getValueAt(i, col) == true)
                                        			this.setValueAt(false, i, col);
                                        		
                                        	if ((Boolean) this.getValueAt(8, col) == true ){
                                        			
                                        		this.setValueAt(false, 5, col);
                                        		this.setValueAt(false, 6, col);
                                        		this.setValueAt(false, 7, col);
                                        		
                                        	}
                                    			
                                    }
                                	
                               if (row == 9){
                                       for (int i=9; i<11; i++ )
                                            if (row !=9)
                                            	if ((Boolean) this.getValueAt(i, col) == true)
                                            		this.setValueAt(false, i, col);
                                            		
                                            if ((Boolean) this.getValueAt(9, col) == true ){
                                            			
                                            	this.setValueAt(false, 10, col);
	
                                            }
                                        			
                               }else
                            	   if (row == 10){
                                       for (int i=9; i<11; i++ )
                                            if (row !=10)
                                            	if ((Boolean) this.getValueAt(i, col) == true)
                                            		this.setValueAt(false, i, col);
                                            		
                                            if ((Boolean) this.getValueAt(10, col) == true ){
                                            			
                                            	this.setValueAt(false, 9, col);
	
                                            }
                                        			
                               }
            	}
                else if ((Boolean) this.getValueAt(row, col) == false) {
                    //code goes here
                }
                
    
        }

        @Override
        public Class<?> getColumnClass(int col) {
            if (col == CHECK_COL) {
                return getValueAt(0, CHECK_COL).getClass();
            }
            return super.getColumnClass(col);
        }

        @Override
        public boolean isCellEditable(int row, int col) {
            Object o = getValueAt(row, col);
            boolean b = o instanceof Boolean && (Boolean) o;
            return col == CHECK_COL ;
        }
    }

    private static void createAndShowUI() {
        JFrame frame = new JFrame("CheckOne");
        frame.add(new CTCNextDate());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

	
	
}
