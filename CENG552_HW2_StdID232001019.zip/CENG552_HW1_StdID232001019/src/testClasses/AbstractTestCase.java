package testClasses;

import java.io.IOException;

import guiClasses.Mainscreen;

public class AbstractTestCase {

	
	public static String[] loadingATC() throws IOException{
		
		return LoadingSheet.getSheet(6, Mainscreen.getPath());
	
	}
	
	
}
