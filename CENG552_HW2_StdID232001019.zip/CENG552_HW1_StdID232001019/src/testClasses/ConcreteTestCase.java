package testClasses;

import java.io.IOException;

import guiClasses.Mainscreen;

public class ConcreteTestCase {

	
	public static String[][] loadingCTC() throws IOException{
		
		return LoadingSheet.getCTC(7, Mainscreen.getPath());
	
	}
	
}
