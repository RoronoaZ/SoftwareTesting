package testClasses;

import java.io.IOException;

import guiClasses.Mainscreen;

public class DecisionTable {

	
	public static String[] loadingDecisionTable() throws IOException{
		
		return LoadingSheet.getSheet(4, Mainscreen.getPath());
	
	}
	
	
}
