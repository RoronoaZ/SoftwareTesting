package testClasses;

import java.io.IOException;

import guiClasses.Mainscreen;

public class Actions {

	
	public static String[] loadingActions() throws IOException{
		
		return LoadingSheet.getSheet(4, Mainscreen.getPath());
	
	}
	
}
