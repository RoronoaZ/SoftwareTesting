package testClasses;

import javax.swing.JTable;

public class ATCNextDate {

	
	public static void addRowND(boolean[] selectedClasses, String[] action, JTable jtab, int counter){
		counter++;
		String actionMsg = "";
		
		for (int j=0; j<action.length; j++)
			if (j==action.length-1)
				actionMsg= actionMsg + action[j];
			else
				actionMsg= actionMsg + action[j] + " | ";
			
		for (int i=0; i<selectedClasses.length; i++){
			
			if (selectedClasses[i])
				jtab.setValueAt(selectedClasses[i], counter-1, i+1);
			else if (!selectedClasses[i])
				jtab.setValueAt("false", counter-1, i+1);
		}
		jtab.setValueAt("ATC"+counter, counter-1, 0);
		jtab.setValueAt(actionMsg, counter-1, 12);
	}
	
	
}
