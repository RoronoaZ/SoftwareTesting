package testClasses;

import java.io.IOException;

import guiClasses.Mainscreen;

public class ReqSheet {

	
	public static String[] loadingRequirements() throws IOException{
		
		return LoadingSheet.getSheet(0, Mainscreen.getPath());
	
	}
	
}
