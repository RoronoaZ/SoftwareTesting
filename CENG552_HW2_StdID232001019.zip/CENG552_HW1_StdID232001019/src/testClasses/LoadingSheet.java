package testClasses;

import java.io.File;
import java.io.IOException;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class LoadingSheet {

	
	
	public static String[][] getCTC(int pos, String file) throws IOException{
		Workbook workbook = null;
		Cell cells[] = new Cell [rowNum(pos,file)+1];
		String data[][] = new String[rowNum(pos,file)+1][colNum(pos,file)];

		try {

        	workbook = Workbook.getWorkbook(new File(file));

            Sheet sheet = workbook.getSheet(pos);

        	for (int i=1; i<sheet.getRows(); i++){
        		for (int j=0; j<sheet.getColumns(); j++){

        		cells[i] = sheet.getCell(j, i);
        		data[i-1][j] = cells[i].getContents()+ "";
        		
        		}
        	}
        	
        	
        } catch (BiffException e) { 
            e.printStackTrace();
        } finally {

            if (workbook != null) {
                workbook.close();
            }

        }
        return data;

		
		
	}
	
	public static String[] getSheet(int pos, String file) throws IOException{
		
		Workbook workbook = null;
		Cell cells[] = new Cell [rowNum(pos,file)];
		String data[] = new String[rowNum(pos,file)];
		
        try {

        	workbook = Workbook.getWorkbook(new File(file));

            Sheet sheet = workbook.getSheet(pos);

        	for (int i=1; i<sheet.getRows(); i++){
        		
        		cells[i] = sheet.getCell(1, i);
        		data[i-1] = cells[i].getContents()+ "";
        		
        	}
        	
        	
        } catch (BiffException e) { 
            e.printStackTrace();
        } finally {

            if (workbook != null) {
                workbook.close();
            }

        }
        return data;
        
    }

	public static int rowNum(int pos, String file) throws IOException{
	
		Workbook workbook = null;
		int numRow = 0;
		
		try{
			workbook = Workbook.getWorkbook(new File(file));
			Sheet sheet = workbook.getSheet(pos);
			numRow = sheet.getRows();
    
			}catch(BiffException e){
			e.printStackTrace();
		}
	return numRow;
	}
	
	
	public static int colNum(int pos, String file) throws IOException{
		
		Workbook workbook = null;
		int numCol = 0;
		
		try{
			workbook = Workbook.getWorkbook(new File(file));
			Sheet sheet = workbook.getSheet(pos);
			numCol = sheet.getRows();
    
			}catch(BiffException e){
			e.printStackTrace();
		}
	return numCol;
	}


}
