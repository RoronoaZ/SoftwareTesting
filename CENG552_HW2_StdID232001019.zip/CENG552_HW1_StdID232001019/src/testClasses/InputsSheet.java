package testClasses;

import java.io.IOException;

import guiClasses.Mainscreen;

public class InputsSheet {

	
	public static String[] loadingInputs() throws IOException{
		
		return LoadingSheet.getSheet(1, Mainscreen.getPath());
	
	}
	
}
