package testAlgorithmClasses;

public class TriangleAlgorithm {
	
	public String action;
	
	public String triangleProblem(String a, String b, String c){
		
		
		int A = Integer.valueOf(a);
		int B = Integer.valueOf(b);
		int C = Integer.valueOf(c);
		
		if (A > B) { int t=A; A=B; B=t; }
		if (A > C) { int t=A; A=C; C=t; }
		if (B > C) { int t=B; B=C; C=t; }
		
		if (A+B < C)
			this.action = "Not a Triangle";
		else
		{	this.action = "Scalene";
			if (A == B && B == C){
				this.action = "Equilateral";
			}else if (A == B || B == C){
				this.action = "Isosceles";
			}
		
			
		}
		return this.action+"";
	}
	
}
