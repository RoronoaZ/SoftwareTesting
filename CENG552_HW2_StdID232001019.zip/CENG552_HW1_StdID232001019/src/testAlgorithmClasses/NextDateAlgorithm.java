package testAlgorithmClasses;

import java.util.Date;

public class NextDateAlgorithm implements Comparable<Date> {
    private static final int[] SPECIAL_DAYS = { 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    
    private int day=0;     
    private int month=0;   
    private int year=0;    
    
    private String error = "";
   
    public NextDateAlgorithm(int day, int month, int year) {
        if (!isValid(day, month, year)) error = "Invalid";
        this.day   = day;
        this.month = month;        
        this.year  = year;
    }

    
    public NextDateAlgorithm(String date) {
        String[] fields = date.split("-");
        if (fields.length != 3) {
            //throw new IllegalArgumentException("Invalid date");
        		error = "Invalid";
        }
        day = Integer.parseInt(fields[0]);
        month   = Integer.parseInt(fields[1]);
        year  = Integer.parseInt(fields[2]);
        if (!isValid(day, month, year)) error = "Invalid";
    }

    public String getError(){
    	return this.error;
    }

    public int day() {
        return day;
    }
    
    
    public int month() {
        return month;
    }    


    public int year() {
        return year;
    }


    // test whether the date is valid or not ?
    private static boolean isValid(int d, int m,int y) {
        if (m < 1 || m > 12)      return false;
        if (d < 1 || d > SPECIAL_DAYS[m]) return false;
        if (m == 2 && d == 29 && !isLeapYear(y)) return false;
        return true;
    }

    // test whether the year is leap or not ?
    private static boolean isLeapYear(int y) {
        if (y % 400 == 0) return true;
        if (y % 100 == 0) return false;
        return y % 4 == 0;
    }

    // Returns the next date
    public NextDateAlgorithm next() {
        if (isValid(day + 1, month, year))    return new NextDateAlgorithm(day + 1, month, year);
        else if (isValid(1, month + 1,year)) return new NextDateAlgorithm( 1, month + 1,year);
        else                                  return new NextDateAlgorithm(1, 1, year + 1);
    }

    
    @Override
    public String toString() {
        return day + "-" + month + "-" + year;
    }
    
    
    public boolean compareTo(NextDateAlgorithm that) {
        if ((this.year  < that.year)  ||
        	(this.year  > that.year)  ||
        	(this.month < that.month) ||
        	(this.month > that.month) ||
        	(this.day   < that.day)   ||
        	(this.day   > that.day))  return false;
 
        return true;
    }

	@Override
	public int compareTo(Date o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
