package guiClasses;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;

/*
 * Source code written by Anes Abdennebi  
 * This work is licensed under a Creative Commons Attribution 3.0 International License.
 * CC-BY
 */
public class Mainscreen {

	private JFrame frame;
	private JButton btnChooseAFile = new JButton();
	private JTextField path;
	protected static JButton openDT;
	private JLabel loadingStat;
	private JLabel lblFilePath;
	private ImageIcon winIcon;
	protected static String filePath;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainscreen window = new Mainscreen();
					window.frame.setVisible(true);
					window.frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Mainscreen() {

		initialize();
		actions();
		
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		winIcon = new ImageIcon("C:\\Users\\pc\\Documents\\NetBeansProjects\\icon-testing.png");
		ImageIcon fileIcon = new ImageIcon("C:\\Users\\pc\\Documents\\NetBeansProjects\\folder.png");
		ImageIcon startIcon = new ImageIcon("C:\\Users\\pc\\Documents\\NetBeansProjects\\play-icon.png");
		
		frame.setTitle("ST Tool");
		frame.setIconImage(winIcon.getImage());
		frame.setBounds(100, 100, 1024, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		btnChooseAFile.setToolTipText("Choose a file");
		
		
		btnChooseAFile.setBounds(431, 136, 140, 140);
		btnChooseAFile.setIcon(fileIcon);
		panel.add(btnChooseAFile);
		
		JLabel lblChooseAnExcel = new JLabel("Choose an Excel file");
		lblChooseAnExcel.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 20));
		lblChooseAnExcel.setBounds(411, 99, 179, 24);
		panel.add(lblChooseAnExcel);
		
		path = new JTextField();
		path.setEditable(false);
		path.setBounds(176, 342, 649, 33);
		panel.add(path);
		path.setColumns(10);
		
		openDT = new JButton();
		openDT.setToolTipText("Open the decision table");
		openDT.setBounds(431, 466, 140, 140);
		openDT.setEnabled(false);
		openDT.setIcon(startIcon);
		panel.add(openDT);
		
		loadingStat = new JLabel("");
		loadingStat.setHorizontalAlignment(SwingConstants.CENTER);
		loadingStat.setFont(new Font("Tahoma", Font.PLAIN, 18));
		loadingStat.setBounds(409, 411, 181, 24);
		panel.add(loadingStat);
		
		lblFilePath = new JLabel("File path :");
		lblFilePath.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblFilePath.setBounds(51, 341, 97, 34);
		panel.add(lblFilePath);
		
		frame.setVisible(true);
	}
	
	
	private void actions(){
		
		btnChooseAFile.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				fileLoading();
				ProgramChooser chooser = new ProgramChooser();
				chooser.setVisible(true);
				
				
			}
		});
		
		openDT.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				
					DT decisionOpen;
					try {
						decisionOpen = new DT();
						decisionOpen.setTitle("ST Tool - Decision Table");
						decisionOpen.setIconImage(winIcon.getImage());
						decisionOpen.setVisible(true);
					} catch (IOException e) {
					
						e.printStackTrace();
					  }			
					
				}
			
			});
	}
	
	
	protected void fileLoading(){
		
		JFileChooser chooser;
		String choosertitle="Choose a file";

		chooser = new JFileChooser(); 
	    chooser.setCurrentDirectory(new java.io.File("."));
	    chooser.setDialogTitle(choosertitle);
	    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
	    //
	    // disable the "All files" option.
	    //
	    chooser.setAcceptAllFileFilterUsed(true);
	    //    
	    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) { 
	      
	     
	      updatePath(""+chooser.getSelectedFile());		//Display the path of the selected file
	      filePath = chooser.getSelectedFile()+"";		//Assigning the path to the variable filePath
	      loadingStat.setText("Loading Successful");	//Show a message of a successful loading
	      
	     					//Enable the button of launching the test

	    }
	    else {
	      loadingStat.setText("No file is selected");
	    }
	
	}
	
	public static String getPath(){
		
		return filePath;
	}
	
	public void updatePath(String directory){
		
		path.setText(directory);
	}
	
	}
	

