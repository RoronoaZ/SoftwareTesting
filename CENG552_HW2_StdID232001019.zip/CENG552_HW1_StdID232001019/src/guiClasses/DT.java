package guiClasses;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.IOException;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;


import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import testAlgorithmClasses.NextDateAlgorithm;
import testAlgorithmClasses.TriangleAlgorithm;
import testClasses.ATCNextDate;
import testClasses.AbstractTestCase;
import testClasses.Actions;
import testClasses.CTCNextDate;
import testClasses.ConcreteTestCase;
import testClasses.Conditions;
import testClasses.InputsSheet;
import testClasses.LoadingSheet;
import testClasses.OutputsSheet;
import testClasses.ReqSheet;

/*
 * Source code written by Anes Abdennebi  
 * This work is licensed under a Creative Commons Attribution 3.0 International License.
 * CC-BY 
 */

public class DT extends JFrame {

	private JPanel contentPane;
	private JButton run;	
	private JButton runTest;
	private JButton btnSaveConcrete;
	private static JButton btnSaveToAn;
	private DefaultTableModel model, modelInp, modelOut, modelCond, modelAct, modelCTC;
	private static DefaultTableModel modelACT; 
	private static DefaultTableModel modelDecTab;
	private JTabbedPane jtp;
	private JPanel panel, Req, Inputs, Outputs, Cond, Act;
	private static JPanel DecTab;
	private static JPanel AbsTC, CTC;
	private static JLabel lblAbstractTestCase;
	private static boolean[] values;
	private static boolean[] selectedClasses;
	private static String[] actionMessage;
	public static int count=0;
	public static int countND=0;
	public static int rowsInATC=0;
	protected JTable tableCTC;
	protected static JTable table;
	protected static CTCNextDate check;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					DT frame = new DT();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public DT() throws IOException {
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		
		setContentPane(contentPane);
		
		// --------------------------------------- MAIN METHODS -------------------------------------------
		genTabs();				
		displayAllTabs();
		// ------------------------------------------------------------------------------------------------
		
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		

		
	}

	
	public void displayAllTabs() throws IOException{
		
		displayReqTable();
		displayInputs();
		displayOuts();
		displayConds();
		displayActs();
		fillDecisionTable(LoadingSheet.rowNum(5,Mainscreen.getPath()));
		displayConcreteTC();
		
	}
	
	
	public static void fillDecisionTable(int numRows) throws IOException{  //method of filling decision table and Abstract Test Case table
		
														
		DecTab.setLayout(null);
        
        JLabel lblDecisionTable = new JLabel("Decision Table");
        lblDecisionTable.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
        lblDecisionTable.setBounds(424, 13, 139, 21);
        DecTab.add(lblDecisionTable);
		
		int fullTabLen = Conditions.loadingConditions().length;   // Length of conditions & action +1
		
		JButton btnGen = new JButton("Generate Rule");
		btnGen.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
		btnGen.setBounds(502, 559, 206, 35);
		btnGen.setEnabled(true);
		DecTab.add(btnGen);
		JLabel Rules = new JLabel("");
		Rules.setHorizontalAlignment(SwingConstants.CENTER);
		Rules.setFont(new Font("Times New Roman", Font.BOLD, 18));
		Rules.setBounds(250, 626, 487, 33);
		DecTab.add(Rules);
		
		// ScrollPane for Table
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(135, 43, 720, 550);
				DecTab.add(scrollPane);

		// Table
				table = new JTable();
				scrollPane.setViewportView(table);
				
				table.setSize(720, 500);
				scrollPane.setSize(720, 500);
				// Model for Table
				DefaultTableModel model = new DefaultTableModel() {

					public Class<?> getColumnClass(int column) {		//Modeling checkboxes
						switch (column) {
						case 0:
							return Boolean.class;
						case 1:
							return String.class;
						case 2:
							return String.class;
						case 3:
							return String.class;
						case 4:
							return String.class;
						case 5:
							return String.class;
						case 6:
							return String.class;

						default:
							return String.class;
						}
					}
				};
				
				
				table.setModel(model);
				model.addColumn("Rules");
				model.addColumn("Conditions");
				
				if (ProgramChooser.triOrNext()==1){

					// Data Row				
					for (int i = 0; i < fullTabLen-1; i++) {			//	Adding rows in decision table
						
						model.addRow(new Object[0]);
						model.setValueAt(Conditions.loadingConditions()[i].toString()+"", i, 1);
						
					}
						
					table.getModel().addTableModelListener(new TableModelListener() {
						
			              public void tableChanged(TableModelEvent e) {	 
			            	  values = new boolean[table.getModel().getRowCount()];
			                 }  
			    });											
				}
				else {	//Initializing the decision table for NextDate Prob	
						check = new CTCNextDate();
						JScrollPane scroll = new JScrollPane();
					    scrollPane.setViewportView(check);
					    DecTab.add(scrollPane);
					    //Table added	  		
					    
					}
				
				JTable ATCtable ; 									// Creating the Abstract Test Case table			
				String cols[] = new String[Conditions.loadingConditions().length+1];
				cols[0] = "Rules|Conditions";
				
				for(int i=1; i<cols.length-1; i++){
					cols[i] = "C"+i;
				}
				cols[cols.length-1] = "Actions";
				
				modelACT = new DefaultTableModel(cols,Conditions.loadingConditions().length
													+ Actions.loadingActions().length);	
				ATCtable=new JTable(modelACT){
					@Override 
					public boolean isCellEditable(int arg0, int arg1) { 
						return false; 
						}
					}; 
				
				JScrollPane	pane = new JScrollPane(ATCtable); 
				pane.setBounds(70, 45, 850, 550);
				AbsTC.add(pane);
				ATCtable.setSize(1024, 768);
				// Abstract table has been created 
				
				JButton Copy = new JButton("Copy Rule");						//	Creating the rule copying button
				Copy.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
				Copy.setEnabled(false);
				Copy.setBounds(284, 559, 206, 35);
				DecTab.add(Copy);
				
				for(int i=0; i<table.getModel().getRowCount();i++){
						table.getModel().setValueAt(true, i, 0);
				}
				
				btnGen.addActionListener(new ActionListener(){					// Adding action to rule generating button

  					@Override
  					public void actionPerformed(ActionEvent arg0) {
  						
  						if (ProgramChooser.triOrNext()==1){
  							try{	

  								for(int i=0;i<table.getModel().getRowCount();i++){
  									
  									if ((Boolean) table.getModel().getValueAt(i, 0))
  										values[i] = false;
  									else 
  										values[i] = true;	
  								}
  						
  						//--------- Decision table rules (Triangle Problem) to be filled in Abstract test case table
  						if (values[0] || !values[0] && values[1] || !values[0] && !values[1] && values[2])
  							Rules.setText("It is not a triangle");
  						else if ((values[3] && !values[4] && !values[5]) || (!values[3] && values[4] && !values[5])
  								|| (!values[3] && !values[4] && values[5]))
  							Rules.setText("Impossible");
  						else if ((values[3] && values[4] && !values[5]) || (!values[3] && values[4] && values[5])
  								|| (values[3] && !values[4] && values[5]))
  							Rules.setText("It is an Isosceles");
  						else if ((!values[3] && !values[4] && !values[5]))
  							Rules.setText("It is Equilateral");
  						else if ((values[3] && values[4] && values[5]))
  							Rules.setText("It is Scalene");
  						else
  							Rules.setText("Impossible");
  						//--------- End of addition
  						
  						
  							}catch(Exception exc){
  							
  							}
  						}
  						
  						else{	//Get the boolean values from the decision table of NextDate program
  							selectedClasses = new boolean[11];
  								for (int i=0; i<11; i++)
  									selectedClasses[i] = false;
								
								for (int i=0; i<11; i++){
									selectedClasses[i] = (Boolean) check.getTable().getValueAt(i, 1);		
									}
								

  						// ----------------------Filling Abstract Test Cases (NextDate)----------------------
  						if (selectedClasses[4]&&selectedClasses[5] || selectedClasses[2]&&selectedClasses[8]&&selectedClasses[10]
  						 || selectedClasses[3]&&selectedClasses[8] || selectedClasses[4]&&selectedClasses[8]){
  							actionMessage = new String[1];
  							actionMessage[0] = "Impossible";
  						}
  						else
  							
  							if (((selectedClasses[3]&&selectedClasses[5]) || (selectedClasses[3]&&selectedClasses[5]) && ((selectedClasses[9]||selectedClasses[10]))) 
  			  				|| (((selectedClasses[4]&&selectedClasses[6]) || (selectedClasses[4]&&selectedClasses[6]) && ((selectedClasses[9]||selectedClasses[10])))
  			  				|| 	  selectedClasses[1]&&selectedClasses[8]&&selectedClasses[10]
  			  				|| 	  selectedClasses[2]&&selectedClasses[8]&&selectedClasses[9]))
  			  					{
  			  						actionMessage = new String[2];
  			  						actionMessage[0] = "Reset day"; actionMessage[1] = "Increment month";
  			  					}
  							
  						else
  							if ((selectedClasses[4]&&selectedClasses[7]) || ((selectedClasses[4]&&selectedClasses[7])   								 
  	  						&&  (selectedClasses[9]||selectedClasses[10]) )){
  	  									actionMessage = new String[3];
  	  									actionMessage[0] = "Reset day"; actionMessage[1] = "Reset month"; actionMessage[2] = "Increment year";
  							}
  							
  					else
  						if (((selectedClasses[0]&&selectedClasses[5] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[0]&&selectedClasses[5]) 
  		  		  		 || ((selectedClasses[1]&&selectedClasses[5] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[1]&&selectedClasses[5])
  		  		  		 || ((selectedClasses[2]&&selectedClasses[5] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[2]&&selectedClasses[5])
  		  		  		 || ((selectedClasses[0]&&selectedClasses[6] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[0]&&selectedClasses[6])
  		  		  		 || ((selectedClasses[1]&&selectedClasses[6] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[1]&&selectedClasses[6])
  		  				 || ((selectedClasses[2]&&selectedClasses[6] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[2]&&selectedClasses[6])
  		  		  		 || ((selectedClasses[3]&&selectedClasses[6] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[3]&&selectedClasses[6])
  		  		  		 || ((selectedClasses[0]&&selectedClasses[7] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[0]&&selectedClasses[7])
  		  		  		 || ((selectedClasses[1]&&selectedClasses[7] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[1]&&selectedClasses[7])
  		  		  		 || ((selectedClasses[2]&&selectedClasses[7] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[2]&&selectedClasses[7])
  		  		  		 || ((selectedClasses[3]&&selectedClasses[7] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[3]&&selectedClasses[7]) 
  		  		  		 || ((selectedClasses[0]&&selectedClasses[8] && (selectedClasses[9]||selectedClasses[10]))) || (selectedClasses[0]&&selectedClasses[8])
  		 				 || (selectedClasses[1]&&selectedClasses[8]&&selectedClasses[9]))
  							
  							{
  		  		  				actionMessage = new String[1];
  		  		  				actionMessage[0] = "Increment day";
  		  		  			}
		
						}			
  						Copy.setEnabled(true);
  					}});
				
				
				Copy.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					
					if (ProgramChooser.triOrNext()==1){
						addRow(values, Rules.getText(), ATCtable);		//Adding rows to ATC table when clicking the Copy Button
						rowsInATC++;
						btnSaveToAn.setEnabled(true);
					}else{
						ATCNextDate.addRowND(selectedClasses, actionMessage, ATCtable, countND);
						countND++;
						btnSaveToAn.setEnabled(true);
					}
				}
					
			});
							
				btnSaveToAn = new JButton("Save to an excel file");
				btnSaveToAn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						try {
								saveToFile(ATCtable,0); //Save Abstract Test Case Table to the desktop
								
						} catch (WriteException e) {
							e.printStackTrace();
						}				
						catch (IOException e) {
							
							e.printStackTrace();
						}
						
					}
				});
				btnSaveToAn.setFont(new Font("Times New Roman", Font.BOLD, 20));
				btnSaveToAn.setBounds(379, 608, 245, 36);
				btnSaveToAn.setEnabled(false);
				AbsTC.add(btnSaveToAn);

	}
	
	
	public static void saveToFile(JTable ATCtable, int sheetNum) throws RowsExceededException, WriteException, IOException{
		
		
		Label lab = null;
		WritableWorkbook workbook = null ;
		WritableSheet writablesheet = null ;
		String[] FIRST_COLUMN = {"Concrete Test Cases","Input Variables","","","Expected Variables",
				 "","Observed Outputs","","Test result"};
		
	if (ProgramChooser.triOrNext()==1){		
		try {
			try{
		    String fileName = "Desktop\\Triangle_Problem.xls";
		    String[] sheetTitles = {"Abstract Test Case (Triangle Problem)","Concrete Test Case (Triangle Problem)"};
		    workbook = Workbook.createWorkbook(new File("Triangle_Problem.xls"));
		    if (sheetNum==0)
		    	writablesheet = workbook.createSheet(sheetTitles[0], sheetNum);
		    else if (sheetNum==1)
		    	writablesheet = workbook.createSheet(sheetTitles[1], sheetNum);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		if (sheetNum == 0){
		    for(int i=0; i<rowsInATC+1; i++){															// Inserting the first row titles
		    	if (i==0){	
	    			lab = new Label(0,i,"Rules | Conditions");
	    			writablesheet.addCell(lab);
	    			for (int j=1; j<=ATCtable.getColumnCount()-1; j++){
	    				lab = new Label(j,i,Conditions.loadingConditions()[j-1]);
	    				writablesheet.addCell(lab);
	    			}
	    			lab = new Label(ATCtable.getColumnCount()-1,i,"Actions");
	    			writablesheet.addCell(lab);														// End of inserting the first row
	    		}
		    	else
		    	for (int j=0; j<ATCtable.getColumnCount(); j++){
		    		
		    		
		    		if (!ATCtable.getValueAt(i-1, j).equals(null)){
		    			lab = new Label(j,i,ATCtable.getValueAt(i-1, j).toString());
		    			writablesheet.addCell(lab);
		    		}
		    	}
		    }
		}
		
		else if (sheetNum==1){
			
			
			
			for(int i=0; i<FIRST_COLUMN.length; i++){
				lab = new Label(i,0,FIRST_COLUMN[i].toString());
				writablesheet.addCell(lab);
			}
			
			for(int i=1; i<ATCtable.getRowCount(); i++)
			
				for (int j=0; j<ATCtable.getColumnCount(); j++){
		    				    	System.out.println(ATCtable.getRowCount());
		    	
		    		if (ATCtable.getModel().getValueAt(i-1, j) != null){
		    			lab = new Label(j,i,ATCtable.getValueAt(i-1, j).toString());
		    			writablesheet.addCell(lab);
		    		}
		    	
			}
			
		}
		    
		    workbook.write();			// Save the work on the excel file
		    workbook.close();			// Close the file after finishing working on it
		    JOptionPane.showMessageDialog(null,"Your file has been successfully saved to the IDE workspace");

		} catch (WriteException e) {

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	else {
		
		try{
			String fileName = "Desktop\\Next_Date_Problem.xls";
			String[] sheetTitles = {"Abstract Test Case (Next date Problem)","Concrete Test Case (Next date Problem)"};
		    workbook = Workbook.createWorkbook(new File("Next_Date_Problem.xls"));
		    
		    if (sheetNum==0)
		    	writablesheet = workbook.createSheet(sheetTitles[0], sheetNum+2);
		    else
		    	writablesheet = workbook.createSheet(sheetTitles[1], sheetNum+2);
		    
		}catch(Exception e){
				e.printStackTrace();
			}
		
		if (sheetNum==0){
		    for(int i=0; i<countND+1; i++){															// Inserting the first row titles
		    	if (i==0){	
	    			lab = new Label(0,i,"Rules | Conditions");
	    			writablesheet.addCell(lab);
	    			for (int j=1; j<=ATCtable.getColumnCount()-1; j++){
	    				System.out.println(j);
	    				lab = new Label(j,i,Conditions.loadingConditions()[j-1]);
	    				writablesheet.addCell(lab);
	    			}
	    			lab = new Label(ATCtable.getColumnCount()-1,i,"Actions");
	    			writablesheet.addCell(lab);														// End of inserting the first row
	    		}
		    	else
		    		for (int j=0; j<ATCtable.getColumnCount(); j++){
			    		
			    		
			    		if (!ATCtable.getValueAt(i-1, j).equals(null)){
			    			lab = new Label(j,i,ATCtable.getValueAt(i-1, j).toString());
			    			writablesheet.addCell(lab);
			    		}
			    	}
		    }
		}
		else if (sheetNum==1)
		{
				
			for(int i=0; i<FIRST_COLUMN.length; i++){
				lab = new Label(i,0,FIRST_COLUMN[i].toString());
				writablesheet.addCell(lab);
			}
			
			for(int i=1; i<ATCtable.getRowCount(); i++)
			
				for (int j=0; j<ATCtable.getColumnCount(); j++){
		    				    	System.out.println(ATCtable.getRowCount());
		    	
		    		if (ATCtable.getModel().getValueAt(i-1, j) != null){
		    			lab = new Label(j,i,ATCtable.getValueAt(i-1, j).toString());
		    			writablesheet.addCell(lab);
		    		}
		    	
			}
		}
		    workbook.write();			// Save the work on the excel file
		    workbook.close();			// Close the file after finishing working on it
		    JOptionPane.showMessageDialog(null,"Your file has been successfully saved to the IDE workspace");

	}
	

	}
	    
	
	
	
	public static void addRow(boolean[] values, String Action, JTable jtab){
		count++;
		boolean exist = true;				//ATC exist already or not
	if (count!=1){	
		for (int i=0; i<count-1 ; i++)
			if (jtab.getModel().getValueAt(i, 1).toString().contains("ACT"+i))
				for (int j=0; j<values.length; j++){
					System.out.println("i"+i);
					System.out.println("j"+j);
					if (values[j]!= (boolean)jtab.getModel().getValueAt(i, j+1))
							exist = false;
				}
			
	}
	
	if(exist){
		for (int i=0; i<values.length; i++){
			if (i==0 && values[i]){
				jtab.setValueAt(!values[i], count-1, i+1);
				for (int j=i+1; j<values.length; j++){
					jtab.setValueAt("--", count-1, j+1);
					System.out.println(j);
					
			}
				i=values.length;
			}
			else if (i==1 && values[i]){
				jtab.setValueAt(!values[i], count-1, i+1);
			for (int j=i+1; j<values.length; j++){
				jtab.setValueAt("--", count-1, j+1);
				System.out.println(j);
				
			}     i=values.length;
			}
			else
				if (i==2 && values[i]){
					jtab.setValueAt(!values[i], count-1, i+1);
				for (int j=i+1; j<values.length; j++){
					jtab.setValueAt("--", count-1, j+1);
					System.out.println(j);
					
				}     i=values.length;
				}else
		
				jtab.setValueAt(!values[i], count-1, i+1);
		
		}
		jtab.setValueAt(Action, count-1, values.length+1);
		jtab.setValueAt("ACT"+count, count-1, 0);
	}
	}
	
	
	
	public void displayConcreteTC() throws IOException{
		
																		//Creating the table where the CTC's will be displayed
		String col[] = {"Concrete Test Cases","Input Variables","","","Expected Outputs","","Observed Outputs","","Test Results"};
		String data[][];
		
		data = ConcreteTestCase.loadingCTC();							//Getting the correspondent sheet (Concrete TC)
		
		modelCTC = new DefaultTableModel(col,data.length);	
		
		tableCTC=new JTable(modelCTC){
			@Override 
			public boolean isCellEditable(int arg0, int arg1) { 
				return false; 
				}
			}; 
		
		for (int i=0; i<=LoadingSheet.rowNum(7, Mainscreen.getPath())-2; i++){
			for (int j=0; j<LoadingSheet.colNum(7, Mainscreen.getPath())-2; j++){
				if (!data[i][j].isEmpty()){
					tableCTC.setValueAt(data[i][j], i, j);
					tableCTC.setValueAt("CTC"+(i+1), i+2, 0);
				}
			}
		}
		
		runTest = new JButton("Run Tests");
		
		runTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				jtp.setSelectedIndex(5);
				btnSaveConcrete.setEnabled(true);
				
				if (ProgramChooser.triOrNext()==1){
					TriangleAlgorithm test = new TriangleAlgorithm();
					String actionMsg;
					try {
						for (int i=2; i<LoadingSheet.rowNum(7, Mainscreen.getPath())-1; i++){
						
							actionMsg = test.triangleProblem(ConcreteTestCase.loadingCTC()[i][1], 
				 				  ConcreteTestCase.loadingCTC()[i][2], 
				 				  ConcreteTestCase.loadingCTC()[i][3]);
						
							if (!actionMsg.contains("Not a Triangle"))
							
								updateCTCTable(tableCTC,actionMsg, i, 6);
							else
								updateCTCTable(tableCTC, actionMsg, i, 7);
						}

						passOrFail(tableCTC);
					
					} catch (IOException e) {
					
						e.printStackTrace();
						}
					}
				else {
					//String nextDate;
					
					try {
						for (int i=2; i<LoadingSheet.rowNum(7, Mainscreen.getPath())-1; i++){
							
							NextDateAlgorithm nextDate= new NextDateAlgorithm(Integer.parseInt(ConcreteTestCase.loadingCTC()[i][1]), 
									  Integer.parseInt(ConcreteTestCase.loadingCTC()[i][2]), 
									  Integer.parseInt(ConcreteTestCase.loadingCTC()[i][3]));
							
								if (!nextDate.getError().toString().contains("Invalid"))
							//if (!nextDate.next().toString().)
									updateCTCTable(tableCTC,nextDate.next().toString(), i, 6);
							//else
								//updateCTCTable(tableCTC, actionMsg, i, 7);
								else 
									updateCTCTable(tableCTC,"Invalid", i, 7);
						}
						
						passOrFail(tableCTC);
						
					} catch (NumberFormatException | IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
					
				}
			}
				
				
		});
		
		CTC.setLayout(null);
		
		CTC.add(runTest);
		runTest.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 18));
		runTest.setBounds(288, 608, 200, 33);
		
		
		
		JScrollPane	pane = new JScrollPane(tableCTC); 
		pane.setBounds(70, 45, 850, 550);
		CTC.add(pane);
		
		tableCTC.setSize(720, 500);
		
		JLabel lblCTC = new JLabel("Concrete Test Cases");
		lblCTC.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
		lblCTC.setBounds(401, 13, 200, 27);
		CTC.add(lblCTC);
		
		btnSaveConcrete = new JButton("Save to the output file");
		btnSaveConcrete.setEnabled(false);
		btnSaveConcrete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					
					saveToFile(tableCTC,1);
					
				} catch (WriteException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		btnSaveConcrete.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 18));
		btnSaveConcrete.setBounds(500, 608, 218, 33);
		CTC.add(btnSaveConcrete);
		
		setVisible(true); 
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		
		
	}
	
		
	
	public void displayActs() throws IOException {
			
		JTable table4 ; 												//Creating the table where the actions will be displayed
		String col[] = {"Actions"," "};
		String data[];
		
		data = Actions.loadingActions();			//Getting the correspondent sheet (Actions)
		
		modelAct = new DefaultTableModel(col,data.length);	
		
		table4=new JTable(modelAct){
			@Override 
			public boolean isCellEditable(int arg0, int arg1) { 
				return false; 
				}
			}; 
		
		for (int i=0; i<data.length-1; i++){
			
			table4.setValueAt(data[i], i, 1);
			table4.setValueAt("ACT"+(i+1), i, 0);
			if (table4.getValueAt(i, 1)=="")
				table4.remove(i);
			
		}
		
		run = new JButton("Fill Decision Table");
		run.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jtp.setSelectedIndex(5);
			}
		});
		Act.setLayout(null);
		
		Act.add(run);
		run.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 18));
		run.setBounds(395, 611, 200, 33);
		
		
		
		JScrollPane	pane = new JScrollPane(table4); 
		pane.setBounds(70, 45, 850, 550);
		Act.add(pane);
		
		table4.setSize(720, 500);
		
		JLabel lblActions = new JLabel("Actions");
		lblActions.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
		lblActions.setBounds(453, 13, 81, 27);
		Act.add(lblActions);
		
		setVisible(true); 
		setDefaultCloseOperation(EXIT_ON_CLOSE);


	}
	
	public void displayConds() throws IOException{
			
		JTable table3 ; 												//Creating the table where the conditions will be displayed
		String col[] = {"Conditions"," "};
		String data[];
		
		data = Conditions.loadingConditions();			//Getting the correspondent sheet (Conditions)
		
		modelCond = new DefaultTableModel(col,data.length);	
		
		table3=new JTable(modelCond){
			@Override 
			public boolean isCellEditable(int arg0, int arg1) { 
				return false; 
				}
			}; 
		
		for (int i=0; i<data.length-1; i++){
			
			table3.setValueAt(data[i], i, 1);
			table3.setValueAt("C"+(i+1), i, 0);
			if (table3.getValueAt(i, 1)=="")
				table3.remove(i);
			
		}
		
		run = new JButton("Fill Decision Table");
		run.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jtp.setSelectedIndex(5);
			}
		});
		Cond.setLayout(null);
		
		Cond.add(run);
		run.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 18));
		run.setBounds(395, 611, 200, 33);
		
		
		
		JScrollPane	pane = new JScrollPane(table3); 
		pane.setBounds(70, 45, 850, 550);
		Cond.add(pane);
		
		table3.setSize(720, 500);
		
		JLabel lblOutputs = new JLabel("Conditions");
		lblOutputs.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
		lblOutputs.setBounds(443, 13, 101, 27);
		Cond.add(lblOutputs);
		
		setVisible(true); 
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		
		
	}
	
	
	public void displayOuts() throws IOException {
			
		JTable table2 ; 												//Creating the table where the outputs will be displayed
		String col[] = {"Outputs"," "};
		String data[];
		
		data = OutputsSheet.loadingOutputs();			//Getting the correspondent sheet (Outputs)
		
		modelOut = new DefaultTableModel(col,data.length);	
		
		table2=new JTable(modelOut){
			@Override 
			public boolean isCellEditable(int arg0, int arg1) { 
				return false; 
				}
			}; 
		
		for (int i=0; i<data.length-1; i++){
			
			table2.setValueAt(data[i], i, 1);
			table2.setValueAt("OV"+(i+1), i, 0);
			if (table2.getValueAt(i, 1)=="")
				table2.remove(i);
			
		}
		
		run = new JButton("Fill Decision Table");
		run.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jtp.setSelectedIndex(5);
			}
		});
		Outputs.setLayout(null);
		
		Outputs.add(run);
		run.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 18));
		run.setBounds(395, 611, 200, 33);
		
		
		
		JScrollPane	pane = new JScrollPane(table2); 
		pane.setBounds(70, 45, 850, 550);
		Outputs.add(pane);
		table2.setSize(720, 500);
		
		JLabel lblOutputs = new JLabel("Outputs");
		lblOutputs.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
		lblOutputs.setBounds(453, 13, 81, 27);
		Outputs.add(lblOutputs);
		
		setVisible(true); 
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		
	}
	
	public void displayInputs() throws IOException {
		
		JTable table1 ; 												//Creating the table where the inputs will be displayed
		String col[] = {"Inputs"," "};
		String data[];
		
		data = InputsSheet.loadingInputs();			//Getting the correspondent sheet (InputsSheet)
		
		modelInp = new DefaultTableModel(col,data.length);	
		
		table1=new JTable(modelInp){
			@Override 
			public boolean isCellEditable(int arg0, int arg1) { 
				return false; 
				}
			}; 
		
		for (int i=0; i<data.length-1; i++){
			
			table1.setValueAt(data[i], i, 1);
			table1.setValueAt("IV"+(i+1), i, 0);
			if (table1.getValueAt(i, 1)=="")
				table1.remove(i);
			
		}
		
		run = new JButton("Fill Decision Table");
		run.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jtp.setSelectedIndex(5);
			}
		});
		Inputs.setLayout(null);
		
		Inputs.add(run);
		run.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 18));
		run.setBounds(395, 611, 200, 33);
		
		
		
		JScrollPane	pane = new JScrollPane(table1); 
		pane.setBounds(70, 45, 850, 550);
		Inputs.add(pane);
		
		table1.setSize(720, 500);
		
		JLabel lblInputs = new JLabel("Inputs");
		lblInputs.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
		lblInputs.setBounds(461, 5, 64, 27);
		Inputs.add(lblInputs);
		
		setVisible(true); 
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
	
	
	public void displayReqTable() throws IOException { 
		
		JTable table; 												//Creating the table where the requirements will be displayed
		String col[] = {"Requirements"," "};
		String data[];
		
		data = ReqSheet.loadingRequirements();		//Getting the correspondent sheet (Requirements)
		
		model = new DefaultTableModel(col,data.length);	
		
		table=new JTable(model){
			@Override 
			public boolean isCellEditable(int arg0, int arg1) { 
				return false; 
				}
			}; 
		
		JScrollPane	pane = new JScrollPane(table); 
		pane.setBounds(255, 5, 452, 402);
		for (int i=0; i<data.length-1; i++){
			
			table.setValueAt(data[i], i, 1);
			table.setValueAt("R"+(i+1), i, 0);
			if (table.getValueAt(i, 1)=="")
				table.remove(i);
			
		}
		panel.setLayout(null);
		
		table.setSize(720, 500);
		panel.add(pane); 
		
		run = new JButton("Fill Decision Table");
		run.setBounds(381, 420, 200, 33);
		panel.add(run);
		run.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jtp.setSelectedIndex(5);
			}
		});
		run.setFont(new Font("Microsoft New Tai Lue", Font.PLAIN, 18));
		
		setVisible(true); 
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}

	
	
	public void genTabs(){
	
		//Creating the Tabbed pane
		setTitle("Tabs");
        jtp = new JTabbedPane();
        getContentPane().add(jtp);
        
        
        //Generating the tabs
        
        Req = new JPanel();						
        Inputs = new JPanel();
        Outputs = new JPanel();
        Cond = new JPanel();
        Act = new JPanel();
        DecTab = new JPanel();
        AbsTC = new JPanel();
        CTC = new JPanel();
        
        Req.setLayout(null);
        
        JLabel label1 = new JLabel();
        label1.setBounds(428, 5, 131, 27);
        label1.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
        label1.setText("Requirements");
        Req.add(label1);
        
        
        jtp.addTab("Requirements", Req);
        
        panel = new JPanel();
        panel.setBounds(14, 56, 963, 503);
        Req.add(panel);
        
        jtp.addTab("Inputs", Inputs);
        jtp.addTab("Outputs",Outputs);
        jtp.addTab("Conditions",Cond);
        jtp.addTab("Actions",Act);
        jtp.addTab("Decision Table",DecTab);
        jtp.addTab("Abstract Test Case", AbsTC);
        jtp.addTab("Concrete Test Case", CTC);
        
        AbsTC.setLayout(null);
        
        lblAbstractTestCase = new JLabel("Abstract Test Case");
        lblAbstractTestCase.setFont(new Font("Microsoft New Tai Lue", Font.BOLD, 20));
        lblAbstractTestCase.setBounds(399, 13, 189, 27);
        AbsTC.add(lblAbstractTestCase);
       
        
	}

	
	public void updateCTCTable(JTable CTCTable, String actionMessage, int row, int column){
		
		CTCTable.setValueAt(actionMessage, row, column);
		
	}
	
	
	public void passOrFail(JTable CTCTable){
		
	if (ProgramChooser.triOrNext()==1){	
		for (int i=2; i<CTCTable.getRowCount()-2; i++)
			if (CTCTable.getValueAt(i, 4)==null)
				if (CTCTable.getValueAt(i, 6)==null)
					if (CTCTable.getValueAt(i, 5).toString().contains(CTCTable.getValueAt(i, 7).toString()))
						CTCTable.setValueAt("Pass", i, 8);
					else
						CTCTable.setValueAt("Fail", i, 8);
				else
					CTCTable.setValueAt("Fail", i, 8);
			else
				if (CTCTable.getValueAt(i, 4).toString().contains(CTCTable.getValueAt(i, 6).toString()))
					CTCTable.setValueAt("Pass", i, 8);
				else 
					CTCTable.setValueAt("Fail", i, 8);
	}
	else{
		
		for (int i=2; i<CTCTable.getRowCount()-2; i++)
			if (CTCTable.getValueAt(i, 4)==null)
				if (CTCTable.getValueAt(i, 6)==null)
					if (CTCTable.getValueAt(i, 5).toString().contains(CTCTable.getValueAt(i, 7).toString()))
						CTCTable.setValueAt("Pass", i, 8);
					else
						CTCTable.setValueAt("Fail", i, 8);
				else
					CTCTable.setValueAt("Fail", i, 8);
			else
				if (CTCTable.getValueAt(i, 4)!=null && CTCTable.getValueAt(i, 6)==null)
					CTCTable.setValueAt("Fail", i, 8);
				else
					CTCTable.setValueAt("Pass", i, 8);
		
		}
	
	
	}
	
}


