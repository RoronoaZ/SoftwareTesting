package guiClasses;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.BorderLayout;
import javax.swing.JButton;

public class ProgramChooser extends JFrame {

	private JPanel contentPane;
	private static int chosenProg;
	private JButton btnOk ;
	private static boolean flag = false;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProgramChooser frame = new ProgramChooser();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProgramChooser() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 360, 272);
		setTitle("STTool - Choose a program");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setName(getTitle());
		contentPane.setLayout(new FlowLayout());
		
		JLabel lblChooseWhichProgram = new JLabel("Choose which program to go with ?");
		lblChooseWhichProgram.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblChooseWhichProgram.setBounds(30, 10, 281, 24);
		contentPane.add(lblChooseWhichProgram);
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		
		displayChoices();
		setStartAction();
	}

	
	public void displayChoices(){
		
		JRadioButton triangle = new JRadioButton("Trangle program");
		JRadioButton nextDate = new JRadioButton("Next Date program");
		
		ButtonGroup group = new ButtonGroup();
		group.add(triangle);
		group.add(nextDate);
		getContentPane().add(triangle);
		getContentPane().add(nextDate);
		
		btnOk = new JButton("Ok");
		btnOk.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		btnOk.setBounds(122, 187, 97, 25);
		btnOk.setEnabled(false);
		contentPane.add(btnOk);
		
		pack();
		
		triangle.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				if(triangle.isSelected()){
					chosenProg = 1;
					btnOk.setEnabled(true);
				}
			}
			
		});
		
		nextDate.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {

				if(nextDate.isSelected()){
					chosenProg = 2;
					btnOk.setEnabled(true);
					
				}
			}
			
		});
	
	}
	
	private void setStartAction(){
		
		btnOk.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				Mainscreen.openDT.setEnabled(true);
				setVisible(false);
			}	
			
		});
	}
	
	
	
	public static int triOrNext(){
		
		return chosenProg;
	}
	
	
}
